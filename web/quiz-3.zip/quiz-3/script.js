window.onload = pageLoad;
function pageLoad(){
    document.getElementById("addData").onsubmit = clickAdd;

    document.getElementById("updateData").onsubmit = clickUpdate;
}

function clickUpdate(){
    updateData();
    return false;
}

// ทำให้สมบูรณ์
